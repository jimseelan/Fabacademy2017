# FabAcademy_Template
An html/ajax template for the students of Fab Academy

## License
MIT

## Includes
* <a href="http://getbootstrap.com/">Twitter Bootstrap</a>
* <a href="http://jquery.com/">JQuery</a>
* <a href="https://code.google.com/p/google-code-prettify/">google-code-prettify</a>
* <a href="http://jmblog.github.io/color-themes-for-google-code-prettify/github/">GitHub theme for google-code-prettify</a>
* <a href="https://code.google.com/p/jsc3d/">JSC3D</a>
* <a href="https://github.com/thegrubbsian/jquery.ganttView">jquery.ganttView</a>

## Notes
Ajax functionalities won't work locally on Chrome because of "safety settings" (but will work online).
